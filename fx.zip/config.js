window.$config = {
    SERVER_ADDRESS: 'http://127.0.0.1:6060',
    IMG_ADDRESS: 'http://picture-files.oss-cn-qingdao.aliyuncs.com/',
    PERMISSION_BUTTON: true,
    PERMISSION_API: true,
    PLATFORM: 'JIYU'
};
